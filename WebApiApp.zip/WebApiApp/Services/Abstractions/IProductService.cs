﻿using Domain.Models;

namespace Services.Abstractions
{
    public interface IProductService
    {
        public Task<List<Product>> GetAllProducts();
        public Product GetProductById(int id);
        public Task<Product> AddProduct(Product product);
        public Product UpdateProduct(int id, Product product);
        public Product DeleteProduct(int id);
        public Task<List<Product>> GetProductsByCategoryId(int categoryId);
        public decimal GetTotalPriceByCategoryId(int categoryId);
        public Dictionary<int, decimal> GetTotalPricePerCategory();
    }
}
