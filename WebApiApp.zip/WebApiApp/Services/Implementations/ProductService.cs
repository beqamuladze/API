﻿using Domain.Models;
using Data.DBContext;
using Services.Abstractions;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Services.Abstractions;
using System;

namespace Services.Implementations
{
    public class ProductService : IProductService
    {
        public AppDbContext _appDbContext;

        public ProductService(AppDbContext appDbContext)
        {
            _appDbContext = appDbContext;
        }

        public async Task<List<Product>> GetAllProducts()
        {
            var products = await _appDbContext.Products.ToListAsync();

            return products;
        }

        public Product GetProductById(int id)
        {
            var productInDb = _appDbContext.Products.FirstOrDefault(x => id == x.Id);

            return productInDb;
        }

        public async Task<Product> AddProduct(Product product)
        {
            await _appDbContext.Products.AddAsync(product);
            await _appDbContext.SaveChangesAsync();

            return product;
        }

        public Product UpdateProduct(int id, Product product)
        {
            var productInDb = _appDbContext.Products.FirstOrDefault(x => id == x.Id);

            if (productInDb != null)
            {
                productInDb.Name = product.Name;
                productInDb.Price = product.Price;
                productInDb.CategoryId = product.CategoryId;
            }

            _appDbContext.SaveChangesAsync();

            return productInDb;
        }

        public Product DeleteProduct(int id)
        {
            var productInDb = _appDbContext.Products.FirstOrDefault(x => id == x.Id);

            if (productInDb != null)
            {
                _appDbContext.Products.Remove(productInDb);
            }

            _appDbContext.SaveChangesAsync();

            return productInDb;
        }

        public async Task<List<Product>> GetProductsByCategoryId(int categoryId)
        {
            var products = await _appDbContext.Products.Where(x => x.CategoryId == categoryId).ToListAsync();

            return products;
        }

        public decimal GetTotalPriceByCategoryId(int categoryId)
        {
            var products = _appDbContext.Products.Where(x => x.CategoryId == categoryId).Sum(x => x.Price);

            return products;
        }

        public Dictionary<int, decimal> GetTotalPricePerCategory()
        {
            var products = _appDbContext.Products.GroupBy(x => x.CategoryId).ToDictionary(p => p.Key, p => p.Sum(x => x.Price));

            return products;
        }
    }
}
